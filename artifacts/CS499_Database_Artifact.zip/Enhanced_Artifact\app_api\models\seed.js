const mongoose = require('mongoose');
const Trip = require('./travlr');

var fs = require('fs');
var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

const seedDB = async () => {

  if (!process.argv.includes('--apply')) {
    console.log(`Dry run: ${trips.length} sample trips found. No changes made.`);
    return;
  }

  const host = process.env.DB_HOST || '127.0.0.1';
  await mongoose.connect(`mongodb://${host}/travlr`);

  for (const tripData of trips) {
    const exists = await Trip.exists({ code: tripData.code });

    if (!exists) {
      await Trip.create(tripData);
      console.log(`Added ${tripData.code}`);
    } else {
      console.log(`Kept existing ${tripData.code}`);
    }
  }
};

seedDB()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });