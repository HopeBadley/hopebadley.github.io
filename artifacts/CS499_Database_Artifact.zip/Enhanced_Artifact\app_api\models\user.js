const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true
  },
  name: {
    type: String,
    required: true
  },
// Limit each account to an approved authorization role
role: {
  type: String,
  enum: ['customer', 'admin'],
  default: 'customer',
  required: true
},
  hash: String,
  salt: String
});

// Set and securely hash the user's password
userSchema.methods.setPassword = function (password) {
  this.salt = crypto.randomBytes(16).toString('hex');

  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');
};

// Check whether the entered password is correct
userSchema.methods.validPassword = function (password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');

  return this.hash === hash;
};

// Generate a JSON Web Token for the user
userSchema.methods.generateJWT = function () {
// Include the role so protected routes can enforce authorization
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name,
      role: this.role
    },
    process.env.JWT_SECRET,
    {
      expiresIn: '1h'
    }
  );
};

const User = mongoose.model('users', userSchema);

module.exports = User;