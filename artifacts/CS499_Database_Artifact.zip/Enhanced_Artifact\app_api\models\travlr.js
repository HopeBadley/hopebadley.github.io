const mongoose = require('mongoose');
// Define the trip schema
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        trim: true,
        uppercase: true
    },
    name: { type: String, required: true, index: true },
    length: { type: String, required: true },
    start: { type: Date, required: true },
    resort: { type: String, required: true },
    perPerson: {
        type: String,
        required: true,
        validate: {
            validator: (value) =>
                /^\d+(?:\.\d{1,2})?$/.test(value) && Number(value) > 0,
            message: 'Price must be positive with at most two decimal places.'
        }
    },
    image: { type: String, required: true },
    description: { type: String, required: true }
});
tripSchema.index({ code: 1 }, { unique: true });
const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
