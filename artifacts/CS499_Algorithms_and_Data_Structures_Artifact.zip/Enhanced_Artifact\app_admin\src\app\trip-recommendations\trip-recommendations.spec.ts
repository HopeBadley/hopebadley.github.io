import {
  ComponentFixture,
  TestBed
} from '@angular/core/testing';

import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';

import { TripData } from '../services/trip-data';

import {
  TripRecommendations
} from './trip-recommendations';

describe('TripRecommendations', () => {
  let component: TripRecommendations;
  let fixture: ComponentFixture<TripRecommendations>;

  /*
   * Keep the component test independent from the real API and
   * database by providing a controlled TripData replacement.
   */
  const tripDataMock = {
    getRecommendations:
      vi.fn().mockReturnValue(of([]))
  };

  beforeEach(async () => {
    tripDataMock.getRecommendations.mockClear();

    await TestBed.configureTestingModule({
      imports: [TripRecommendations],
      providers: [provideRouter([])]
    })
      /*
       * The component declares its own TripData provider, so override
       * that provider with the controlled unit-test version.
       */
      .overrideComponent(
        TripRecommendations,
        {
          set: {
            providers: [
              {
                provide: TripData,
                useValue: tripDataMock
              }
            ]
          }
        }
      )
      .compileComponents();

    fixture = TestBed.createComponent(
      TripRecommendations
    );

    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /*
   * A reversed date range must be rejected before an unnecessary API
   * request is sent.
   */
  it('should reject a reversed date range', () => {
    component.preferenceForm.patchValue({
      startDate: '2027-12-31',
      endDate: '2027-01-01'
    });

    component.findRecommendations();

    expect(component.errorMessage).toContain(
      'Start date'
    );

    expect(
      tripDataMock.getRecommendations
    ).not.toHaveBeenCalled();
  });
});