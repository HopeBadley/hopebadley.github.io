# Algorithms and Data Structures Enhancement

## Overview

This enhancement adds a personalized trip recommendation feature to the Travlr Getaways application. Customers can submit travel preferences and receive a ranked list of eligible trips with match scores and explanations.

## Customer Preferences

The recommendation process accepts:

- Preferred destination or resort
- Maximum price per person
- Earliest departure date
- Latest departure date
- Preferred trip length
- Number of requested recommendations

Maximum budget, travel dates, and result limit are required filters. Destination and trip length are optional scoring preferences.

## Weighted Scoring

Each eligible trip receives a score based on four centralized weights:

| Preference | Maximum Points |
|---|---:|
| Destination or resort | 40 |
| Price | 25 |
| Departure date | 20 |
| Trip length | 15 |
| Total | 100 |

Trips outside the required budget or date range are removed before scoring. The final results include a total match score, individual score breakdown, and plain-language reasons explaining the recommendation.

## Min-Heap Selection

A size-k min-heap retains only the strongest requested recommendations. The weakest retained result remains at the root of the heap. When a stronger trip is found, it replaces the root.

This approach avoids sorting and storing every eligible trip.

- Time complexity: O(n log k)
- Additional space complexity: O(k)

In these expressions, n is the number of trips evaluated and k is the number of recommendations requested.

## API Endpoint

```text
POST /api/trips/recommendations
```

Example request:

```json
{
  "destination": "Coral Sands",
  "maxBudget": 2100,
  "startDate": "2027-01-01",
  "endDate": "2027-12-31",
  "preferredLength": 4,
  "resultLimit": 3
}
```

The endpoint validates the preferences and returns either ranked recommendations or clear validation errors.

## Testing

Run the recommendation algorithm tests from the main project folder:

```text
npm run test:recommendations
```

Run the Angular tests from the `app_admin` folder:

```text
npm test -- --watch=false
```

Create the Angular production bundle with:

```text
npm run build
```

The completed enhancement passed seven recommendation algorithm tests, nineteen Angular tests, API validation testing, and production build verification.