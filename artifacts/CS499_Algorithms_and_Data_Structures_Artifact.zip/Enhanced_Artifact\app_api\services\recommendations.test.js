const test = require('node:test');
const assert = require('node:assert/strict');

const {
    recommendTrips,
    validatePreferences
} = require('./recommendations');

/*
 * Controlled sample trips allow each test to evaluate one behavior
 * without requiring MongoDB or the running Express server.
 */
const trips = [
    {
        code: 'ALPHA',
        name: 'Coral Escape',
        resort: 'Coral Sands',
        perPerson: '800.00',
        start: '2026-06-15T08:00:00Z',
        length: '4 nights / 5 days'
    },
    {
        code: 'BRAVO',
        name: 'Lagoon Week',
        resort: 'Blue Lagoon',
        perPerson: '$1,100.00',
        start: '2026-06-20T08:00:00Z',
        length: '6 nights / 7 days'
    },
    {
        code: 'CHARLIE',
        name: 'Luxury Reef',
        resort: 'Coral Sands',
        perPerson: '2200.00',
        start: '2026-06-18T08:00:00Z',
        length: '4 nights / 5 days'
    }
];

// Valid preferences reused by the individual test cases.
const basePreferences = {
    destination: 'Coral Sands',
    maxBudget: 1500,
    startDate: '2026-06-01',
    endDate: '2026-06-30',
    preferredLength: 4,
    resultLimit: 2
};

test('returns the strongest exact match first', () => {
    const result = recommendTrips(
        trips,
        basePreferences
    );

    assert.deepEqual(result.errors, []);
    assert.equal(
        result.recommendations[0].code,
        'ALPHA'
    );

    assert.ok(
        result.recommendations[0].matchScore > 0
    );

    assert.ok(
        result.recommendations[0].matchReasons.length >= 3
    );
});

test('filters trips outside the required budget', () => {
    const result = recommendTrips(
        trips,
        basePreferences
    );

    const includesExpensiveTrip =
        result.recommendations.some(
            (trip) => trip.code === 'CHARLIE'
        );

    assert.equal(includesExpensiveTrip, false);
});

test('returns partial matches when preferences differ', () => {
    const result = recommendTrips(
        trips,
        basePreferences
    );

    assert.equal(result.recommendations.length, 2);

    assert.equal(
        result.recommendations[1].code,
        'BRAVO'
    );
});

test('uses trip code for stable ordering of tied scores', () => {
    const tiedTrips = [
        {
            ...trips[0],
            code: 'B-TRIP'
        },
        {
            ...trips[0],
            code: 'A-TRIP'
        }
    ];

    const result = recommendTrips(
        tiedTrips,
        basePreferences
    );

    assert.deepEqual(
        result.recommendations.map(
            (trip) => trip.code
        ),
        ['A-TRIP', 'B-TRIP']
    );
});

test('returns fewer than k when fewer trips are eligible', () => {
    const result = recommendTrips(
        [trips[0]],
        {
            ...basePreferences,
            resultLimit: 5
        }
    );

    assert.equal(result.recommendations.length, 1);
});

test('returns an empty result when no trips qualify', () => {
    const result = recommendTrips(
        trips,
        {
            ...basePreferences,
            maxBudget: 100
        }
    );

    assert.deepEqual(result.recommendations, []);
});

test('rejects invalid preference input', () => {
    const result = validatePreferences({
        maxBudget: -1,
        startDate: 'invalid',
        endDate: '2026-06-01',
        resultLimit: 20
    });

    assert.ok(result.errors.length >= 3);
});