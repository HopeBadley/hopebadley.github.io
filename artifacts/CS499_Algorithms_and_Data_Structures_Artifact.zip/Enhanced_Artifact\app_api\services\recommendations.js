// Define the maximum contribution of each preference to the final score.
// Keeping these values together makes the algorithm easier to test and adjust.
const WEIGHTS = Object.freeze({
    destination: 40,
    price: 25,
    date: 20,
    length: 15
});

// Limit the number of requested results to prevent oversized responses.
const MAX_RESULTS = 10;

/*
 * Store the strongest trip recommendations in a min-heap.
 *
 * The weakest retained recommendation stays at index 0. When the heap
 * already contains k trips, the algorithm only replaces the root when
 * it finds a stronger recommendation.
 *
 * This avoids sorting and storing every eligible trip. Selecting the
 * strongest k results takes O(n log k) time and O(k) additional space.
 */
class MinHeap {
    constructor(compare) {
        // Array used to represent the binary heap.
        this.items = [];

        // Comparison function determines which recommendation is weaker.
        this.compare = compare;
    }

    // Return the number of recommendations currently retained.
    get size() {
        return this.items.length;
    }

    // Return the weakest retained recommendation without removing it.
    peek() {
        return this.items[0];
    }

    /*
     * Add a recommendation to the end of the array, then move it upward
     * until the min-heap ordering rule is restored.
     */
    push(value) {
        this.items.push(value);
        this.bubbleUp(this.items.length - 1);
    }

    /*
     * Replace the weakest recommendation with a stronger one, then move
     * the replacement downward until the heap is correctly ordered.
     */
    replaceRoot(value) {
        this.items[0] = value;
        this.bubbleDown(0);
    }

    // Return a copy so callers cannot directly modify the heap.
    toArray() {
        return [...this.items];
    }

    /*
     * Compare a newly inserted child with its parent. Swap them whenever
     * the child is weaker, placing the weakest value closer to the root.
     */
    bubbleUp(index) {
        while (index > 0) {
            const parent = Math.floor((index - 1) / 2);

            // Stop once the child is not weaker than its parent.
            if (this.compare(this.items[index], this.items[parent]) >= 0) {
                break;
            }

            // Swap the child and parent using array destructuring.
            [this.items[index], this.items[parent]] =
                [this.items[parent], this.items[index]];

            index = parent;
        }
    }

    /*
     * Compare a replacement root with its children. Move the weaker child
     * upward until the weakest retained value is again at the root.
     */
    bubbleDown(index) {
        while (true) {
            const left = (index * 2) + 1;
            const right = left + 1;
            let smallest = index;

            // Check whether the left child is weaker than the current value.
            if (
                left < this.items.length &&
                this.compare(this.items[left], this.items[smallest]) < 0
            ) {
                smallest = left;
            }

            // Check whether the right child is weaker than the current value.
            if (
                right < this.items.length &&
                this.compare(this.items[right], this.items[smallest]) < 0
            ) {
                smallest = right;
            }

            // No swap is needed when the heap rule is satisfied.
            if (smallest === index) {
                return;
            }

            // Move the weaker child toward the root.
            [this.items[index], this.items[smallest]] =
                [this.items[smallest], this.items[index]];

            index = smallest;
        }
    }
}

/*
 * Convert prices and other numeric values into JavaScript numbers.
 * This supports stored strings such as "799.00" and "$1,199.00".
 */
const parseNumber = (value) => {
    if (typeof value === 'number') {
        return Number.isFinite(value) ? value : NaN;
    }

    if (typeof value !== 'string') {
        return NaN;
    }

    // Remove currency symbols, commas, spaces, and other nonnumeric characters.
    const normalized = value.replace(/[^0-9.-]/g, '');

    return normalized === '' ? NaN : Number(normalized);
};

/*
 * Extract the number of nights from values such as
 * "4 nights / 5 days".
 */
const parseNights = (value) => {
    if (typeof value === 'number') {
        return Number.isFinite(value) ? value : NaN;
    }

    if (typeof value !== 'string') {
        return NaN;
    }

    const nightsMatch = value.match(/(\d+(?:\.\d+)?)\s*nights?/i);

    // Fall back to general number parsing if "nights" is not present.
    return nightsMatch
        ? Number(nightsMatch[1])
        : parseNumber(value);
};

/*
 * Convert a submitted date into a Date object.
 * Return null when the submitted value is not a valid date.
 */
const parseDate = (value) => {
    const date = new Date(value);

    return Number.isNaN(date.getTime()) ? null : date;
};

/*
 * Validate and normalize customer preferences before processing trips.
 * Required filters are budget, date range, and number of results.
 * Destination and trip length are optional scoring preferences.
 */
const validatePreferences = (input = {}) => {
    const errors = [];

    const maxBudget = parseNumber(input.maxBudget);
    const startDate = parseDate(input.startDate);
    const endDate = parseDate(input.endDate);
    const resultLimit = Number(input.resultLimit);

    const preferredLength =
        input.preferredLength === '' ||
            input.preferredLength == null
            ? null
            : parseNights(input.preferredLength);

    // The budget must be usable as a required numeric filter.
    if (!Number.isFinite(maxBudget) || maxBudget <= 0) {
        errors.push('Maximum budget must be a positive number.');
    }

    // Both boundaries are required for the departure-date filter.
    if (!startDate || !endDate) {
        errors.push('A valid start and end date are required.');
    } else if (startDate > endDate) {
        errors.push('Start date must be on or before end date.');
    }

    /*
     * k must be a whole number within a controlled range.
     * The upper limit prevents unnecessarily large responses.
     */
    if (
        !Number.isInteger(resultLimit) ||
        resultLimit < 1 ||
        resultLimit > MAX_RESULTS
    ) {
        errors.push(
            `Number of results must be between 1 and ${MAX_RESULTS}.`
        );
    }

    // Validate the optional length only when the customer provides it.
    if (
        preferredLength !== null &&
        (
            !Number.isFinite(preferredLength) ||
            preferredLength <= 0
        )
    ) {
        errors.push(
            'Preferred trip length must be a positive number.'
        );
    }

    return {
        errors,

        // Normalize destination text so matching is not case-sensitive.
        preferences: {
            destination: String(input.destination || '')
                .trim()
                .toLowerCase(),
            maxBudget,
            startDate,
            endDate,
            preferredLength,
            resultLimit
        }
    };
};

/*
 * Convert a difference into a value between 0 and 1.
 * A value of 1 represents an exact or strongest match.
 * Larger differences produce lower scores.
 */
const ratioScore = (difference, scale) => {
    if (scale <= 0) {
        return difference === 0 ? 1 : 0;
    }

    return Math.max(0, 1 - (difference / scale));
};

/*
 * Apply required filters and calculate the weighted score for one trip.
 * Returning null removes an invalid or ineligible trip from consideration.
 */
const scoreTrip = (trip, preferences) => {
    const price = parseNumber(trip.perPerson);
    const tripDate = parseDate(trip.start);
    const nights = parseNights(trip.length);

    // Ignore trips whose stored values cannot be safely evaluated.
    if (
        !Number.isFinite(price) ||
        !tripDate ||
        !Number.isFinite(nights)
    ) {
        return null;
    }

    /*
     * Budget and date range are required conditions.
     * Trips that violate either condition are filtered before scoring.
     */
    if (
        price > preferences.maxBudget ||
        tripDate < preferences.startDate ||
        tripDate > preferences.endDate
    ) {
        return null;
    }

    const breakdown = {};
    const reasons = [];

    let earned = 0;

    /*
     * Price and date always contribute to the available score because
     * they are required preferences.
     */
    let available = WEIGHTS.price + WEIGHTS.date;

    /*
     * Less expensive eligible trips receive more price points.
     * Every retained trip is still guaranteed to be within budget.
     */
    const priceRatio = ratioScore(
        price,
        preferences.maxBudget
    );

    breakdown.price = priceRatio * WEIGHTS.price;
    earned += breakdown.price;

    reasons.push(
        `$${price.toFixed(2)} per person is within budget`
    );

    /*
     * Dates closest to the center of the requested range receive more
     * date points. Trips outside the range were already removed.
     */
    const rangeSize =
        preferences.endDate - preferences.startDate;

    const rangeCenter =
        preferences.startDate.getTime() + (rangeSize / 2);

    const dateDistance = Math.abs(
        tripDate.getTime() - rangeCenter
    );

    const dateScale = Math.max(rangeSize / 2, 1);

    const dateRatio = ratioScore(
        dateDistance,
        dateScale
    );

    breakdown.date = dateRatio * WEIGHTS.date;
    earned += breakdown.date;

    reasons.push(
        'Departure date is within the selected range'
    );

    /*
     * Only include destination in the available score when the customer
     * provides one. Search both the trip name and resort.
     */
    if (preferences.destination) {
        available += WEIGHTS.destination;

        const searchableDestination =
            `${trip.name} ${trip.resort}`.toLowerCase();

        const isDestinationMatch =
            searchableDestination.includes(
                preferences.destination
            );

        breakdown.destination = isDestinationMatch
            ? WEIGHTS.destination
            : 0;

        earned += breakdown.destination;

        if (isDestinationMatch) {
            reasons.push(
                'Matches the preferred destination or resort'
            );
        }
    }

    /*
     * Score trip length by closeness to the preferred number of nights.
     * Omitted optional preferences do not reduce the final percentage.
     */
    if (preferences.preferredLength !== null) {
        available += WEIGHTS.length;

        const lengthDifference = Math.abs(
            nights - preferences.preferredLength
        );

        const lengthScale = Math.max(
            nights,
            preferences.preferredLength
        );

        const lengthRatio = ratioScore(
            lengthDifference,
            lengthScale
        );

        breakdown.length =
            lengthRatio * WEIGHTS.length;

        earned += breakdown.length;

        if (lengthDifference === 0) {
            reasons.push(
                'Exactly matches the preferred trip length'
            );
        } else {
            reasons.push(
                `${nights} nights is close to the preferred length`
            );
        }
    }

    /*
     * Return the original trip data with an understandable percentage,
     * individual scoring values, and explanations for the user.
     */
    return {
        ...trip,

        matchScore: Math.round(
            (earned / available) * 100
        ),

        matchReasons: reasons,

        scoreBreakdown: Object.fromEntries(
            Object.entries(breakdown).map(
                ([key, value]) => [
                    key,
                    Number(value.toFixed(2))
                ]
            )
        )
    };
};

/*
 * Compare two recommendations.
 *
 * A negative result means the first trip is weaker.
 * A positive result means the first trip is stronger.
 *
 * Trip codes provide consistent ordering when scores are tied.
 */
const compareRecommendations = (first, second) => {
    if (first.matchScore !== second.matchScore) {
        return first.matchScore - second.matchScore;
    }

    return String(second.code).localeCompare(
        String(first.code)
    );
};

/*
 * Validate the preferences, evaluate every trip, and retain the
 * strongest k recommendations in a bounded min-heap.
 */
const recommendTrips = (trips, rawPreferences) => {
    const {
        errors,
        preferences
    } = validatePreferences(rawPreferences);

    // Stop before processing trips when preference input is invalid.
    if (errors.length > 0) {
        return {
            errors,
            recommendations: []
        };
    }

    const heap = new MinHeap(compareRecommendations);

    for (const sourceTrip of trips) {
        /*
         * Mongoose documents provide toObject(). Plain objects from tests
         * and JSON files can be evaluated without conversion.
         */
        const trip =
            typeof sourceTrip.toObject === 'function'
                ? sourceTrip.toObject()
                : sourceTrip;

        const recommendation = scoreTrip(
            trip,
            preferences
        );

        // Skip trips removed by validation or required filtering.
        if (!recommendation) {
            continue;
        }

        /*
         * Fill the heap until it contains k recommendations.
         */
        if (heap.size < preferences.resultLimit) {
            heap.push(recommendation);
        } else if (
            /*
             * Once the heap is full, replace its weakest result only when
             * the current recommendation is stronger.
             */
            compareRecommendations(
                recommendation,
                heap.peek()
            ) > 0
        ) {
            heap.replaceRoot(recommendation);
        }
    }

    /*
     * The heap efficiently selects the strongest k trips but does not
     * store them in display order. Sort only those retained results.
     */
    const recommendations = heap
        .toArray()
        .sort(
            (first, second) =>
                -compareRecommendations(first, second)
        );

    return {
        errors: [],
        recommendations
    };
};

/*
 * Export the algorithm and helper functions for the controller
 * and focused unit tests.
 */
module.exports = {
    MAX_RESULTS,
    MinHeap,
    WEIGHTS,
    parseNights,
    parseNumber,
    recommendTrips,
    scoreTrip,
    validatePreferences
};