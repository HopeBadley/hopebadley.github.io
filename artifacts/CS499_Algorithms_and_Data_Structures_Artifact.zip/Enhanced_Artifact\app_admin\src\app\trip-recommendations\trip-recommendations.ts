import { CommonModule } from '@angular/common';

import {
  ChangeDetectorRef,
  Component
} from '@angular/core';

import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { Router } from '@angular/router';

import {
  RecommendationPreferences,
  TripRecommendation
} from '../models/recommendation';

import { TripData } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-recommendations',

  // Standalone components declare the features used by their template.
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TripCard
  ],

  providers: [TripData],

  templateUrl: './trip-recommendations.html',
  styleUrl: './trip-recommendations.css'
})
export class TripRecommendations {
  recommendations: TripRecommendation[] = [];

  message = '';
  errorMessage = '';
  submitted = false;

  /*
   * Client-side validation provides immediate feedback.
   * The API repeats validation because browser controls cannot be
   * trusted as the application's only protection.
   */
  preferenceForm;

  constructor(
    private formBuilder: FormBuilder,
    private tripDataService: TripData,
    private changeDetector: ChangeDetectorRef,
    private router: Router
  ) {
    this.preferenceForm =
      this.formBuilder.nonNullable.group({
        destination: [''],

        maxBudget: [
          1500,
          [
            Validators.required,
            Validators.min(1)
          ]
        ],

        startDate: [
          '',
          Validators.required
        ],

        endDate: [
          '',
          Validators.required
        ],

        preferredLength: [
          4,
          Validators.min(1)
        ],

        resultLimit: [
          3,
          [
            Validators.required,
            Validators.min(1),
            Validators.max(10)
          ]
        ]
      });
  }

  /*
   * Validate the form and submit normalized preferences to the API.
   */
  findRecommendations(): void {
    this.submitted = true;
    this.errorMessage = '';
    this.message = '';

    if (this.preferenceForm.invalid) {
      this.preferenceForm.markAllAsTouched();

      this.errorMessage =
        'Complete the required preference fields.';

      return;
    }

    const formValue =
      this.preferenceForm.getRawValue();

    // Angular's individual date validators do not compare the range.
    if (formValue.startDate > formValue.endDate) {
      this.errorMessage =
        'Start date must be on or before end date.';

      return;
    }

    const preferences: RecommendationPreferences = {
      destination:
        formValue.destination.trim(),

      maxBudget:
        Number(formValue.maxBudget),

      startDate:
        formValue.startDate,

      endDate:
        formValue.endDate,

      preferredLength:
        formValue.preferredLength
          ? Number(formValue.preferredLength)
          : null,

      resultLimit:
        Number(formValue.resultLimit)
    };

    this.tripDataService
      .getRecommendations(preferences)
      .subscribe({
        next: (recommendations) => {
          this.recommendations = recommendations;

          this.message =
            recommendations.length > 0
              ? `Found ${recommendations.length} recommended trip${recommendations.length === 1 ? '' : 's'
              }.`
              : 'No trips matched the required budget and date range.';

          this.changeDetector.detectChanges();
        },

        error: (error) => {
          const details = error?.error?.errors;

          this.recommendations = [];

          this.errorMessage =
            Array.isArray(details)
              ? details.join(' ')
              : 'Recommendations could not be loaded.';

          this.changeDetector.detectChanges();
        }
      });
  }

  // Return to the complete trip listing.
  backToTrips(): void {
    this.router.navigate(['/']);
  }
}