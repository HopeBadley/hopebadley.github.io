import { Trip } from './trip';

/*
 * Preferences submitted by the customer.
 * Budget, dates, and result limit are required by the API.
 */
export interface RecommendationPreferences {
  destination: string;
  maxBudget: number;
  startDate: string;
  endDate: string;
  preferredLength: number | null;
  resultLimit: number;
}

/*
 * Extend the existing Trip model with the information calculated by
 * the recommendation algorithm.
 */
export interface TripRecommendation extends Trip {
  matchScore: number;
  matchReasons: string[];

  scoreBreakdown: {
    destination?: number;
    price: number;
    date: number;
    length?: number;
  };
}