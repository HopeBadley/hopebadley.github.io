/*
 * Update the original sample departures without deleting trips or
 * changing their MongoDB document IDs.
 */

const mongoose = require('../app_api/models/db');
const Trip = require('../app_api/models/travlr');

const dateUpdates = [
  {
    code: 'GALR210214',
    start: new Date('2027-02-14T08:00:00Z')
  },
  {
    code: 'DAWR210315',
    start: new Date('2027-03-15T08:00:00Z')
  },
  {
    code: 'CLAR210621',
    start: new Date('2027-06-21T08:00:00Z')
  }
];

const updateTripDates = async () => {
  try {
    for (const update of dateUpdates) {
      const result = await Trip.updateOne(
        { code: update.code },
        { $set: { start: update.start } }
      );

      console.log(
        `${update.code}: matched ${result.matchedCount}, ` +
        `modified ${result.modifiedCount}`
      );
    }

    console.log('Trip departure dates updated successfully.');
  } catch (error) {
    console.error(
      'Trip departure dates could not be updated:',
      error.message
    );

    process.exitCode = 1;
  } finally {
    await mongoose.connection.close();
  }
};

updateTripDates(); 