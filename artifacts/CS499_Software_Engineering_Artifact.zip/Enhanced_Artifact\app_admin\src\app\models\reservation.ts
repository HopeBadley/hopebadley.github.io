// Represents reservation data returned by the API

export interface ReservationUser {
  _id: string;
  name: string;
  email: string;
  role: 'customer' | 'admin';
}

export interface ReservationTrip {
  _id: string;
  code: string;
  name: string;
  start: string;
  resort: string;
  perPerson: string;
}

export interface Reservation {
  _id: string;
  user: ReservationUser;
  trip: ReservationTrip;
  travelers: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}