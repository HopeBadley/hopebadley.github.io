// Centralized settings that may change between environments
export const environment = {
    apiBaseUrl: 'http://localhost:3000/api'
};