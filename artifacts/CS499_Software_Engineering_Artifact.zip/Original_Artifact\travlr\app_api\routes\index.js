const jwt = require("jsonwebtoken");
const express = require("express");
const router = express.Router();

// Import controllers
const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");

// Authentication routes
router.route("/register").post(authController.register);
router.route("/login").post(authController.login);

// Trips routes
router
  .route("/trips")
  .get(tripsController.tripsList)
  .post(authenticateJWT, tripsController.tripsAddTrip);

router
  .route("/trips/:tripCode")
  .get(tripsController.tripsFindByCode)
  .put(authenticateJWT, tripsController.tripsUpdateTrip);

// Authenticate the JSON Web Token
function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    console.log("Auth Header Required but NOT PRESENT!");
    return res.sendStatus(401);
  }

  const headers = authHeader.split(" ");

  if (headers.length < 2 || headers[0] !== "Bearer") {
    console.log("Invalid Authorization Header");
    return res.sendStatus(401);
  }

  const token = headers[1];

  if (!token) {
    console.log("Null Bearer Token");
    return res.sendStatus(401);
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      console.log("Token Validation Error!");
      return res.status(401).json("Token Validation Error!");
    }

    req.auth = verified;
    next();
  });
}

module.exports = router;