// CS 499 Software Design and Engineering Enhancement
// Stores the basic relationships needed for the reservation workflow.

const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
      required: true
    },
    trip: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'trips',
      required: true
    },
    travelers: {
      type: Number,
      required: true,
      min: 1,
      max: 12
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'cancelled'],
      default: 'pending',
      required: true
    }
  },
  {
    timestamps: true
  }
);

const Reservation = mongoose.model(
  'reservations',
  reservationSchema
);

module.exports = Reservation;