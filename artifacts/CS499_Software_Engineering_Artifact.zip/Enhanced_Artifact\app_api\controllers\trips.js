const mongoose = require('mongoose');
require('../models/travlr');

const { sendApiError } = require('../utils/api-error');
const Trip = mongoose.model('trips');

// Keep add and update operations consistent
const mapTripFields = (body) => ({
  code: body.code,
  name: body.name,
  length: body.length,
  start: body.start,
  resort: body.resort,
  perPerson: body.perPerson,
  image: body.image,
  description: body.description
});

// GET: /api/trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();
    return res.status(200).json(trips);
  } catch (err) {
    return sendApiError(
      res,
      500,
      'Trips could not be retrieved.',
      err
    );
  }
};

// GET: /api/trips/:tripCode
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return sendApiError(
        res,
        404,
        'Trip not found.'
      );
    }

    return res.status(200).json(trip);
  } catch (err) {
    return sendApiError(
      res,
      500,
      'Trip could not be retrieved.',
      err
    );
  }
};

// POST: /api/trips
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip(mapTripFields(req.body));

    const trip = await newTrip.save();
    return res.status(201).json(trip);
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Trip could not be created. Check the submitted fields.',
      err
    );
  }
};

// PUT: /api/trips/:tripCode
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip
      .findOneAndUpdate(
        { code: req.params.tripCode },
        mapTripFields(req.body),
        {
          new: true,
          runValidators: true
        }
      )
      .exec();

    if (!trip) {
      return sendApiError(
        res,
        404,
        'Trip not found.'
      );
    }

    return res.status(200).json(trip);
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Trip could not be updated. Check the submitted fields.',
      err
    );
  }
};

// DELETE: /api/trips/:tripCode
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Trip
      .findOneAndDelete({
        code: req.params.tripCode
      })
      .exec();

    if (!trip) {
      return sendApiError(
        res,
        404,
        'Trip not found.'
      );
    }

    return res.status(200).json({
      message: 'Trip deleted successfully.',
      trip
    });
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Trip could not be deleted.',
      err
    );
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};