const express = require("express");
const router = express.Router();

// Import controllers
const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");
const reservationsController = require(
  '../controllers/reservations'
);

// Reuse authentication and authorization across protected routes
const {
  authenticateJWT,
  requireRole
} = require('../middleware/auth');

// Authentication routes
router.route("/register").post(authController.register);
router.route("/login").post(authController.login);

// Trips routes
router
  .route("/trips")
  .get(tripsController.tripsList)
  .post(
    authenticateJWT,
    requireRole('admin'),
    tripsController.tripsAddTrip
  );

router
  .route("/trips/:tripCode")
  .get(tripsController.tripsFindByCode)
  .put(
    authenticateJWT,
    requireRole('admin'),
    tripsController.tripsUpdateTrip
  )
  .delete(
    authenticateJWT,
    requireRole('admin'),
    tripsController.tripsDeleteTrip
  );

// Authenticated customers see their own reservations;
// administrators see all reservations
router
  .route('/reservations')
  .get(
    authenticateJWT,
    reservationsController.reservationsList
  )
  .post(
    authenticateJWT,
    reservationsController.reservationsCreate
  );

// Only administrators can change reservation statuses directly
router
  .route('/reservations/:reservationId/status')
  .patch(
    authenticateJWT,
    requireRole('admin'),
    reservationsController.reservationsUpdateStatus
  );

// Customers may cancel their own reservations
router
  .route('/reservations/:reservationId/cancel')
  .patch(
    authenticateJWT,
    reservationsController.reservationsCancel
  );

module.exports = router;