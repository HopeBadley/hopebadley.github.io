import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { Router } from '@angular/router';
import { Authentication } from '../services/authentication';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-card',
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css',
})
export class TripCard {
  @Input() trip!: Trip;
  @Output() tripDeleted = new EventEmitter<string>();
  pendingDeleteCode: string | null = null;
  constructor(
    private router: Router,
    private authenticationService: Authentication,
    private tripDataService: TripData,
    private changeDetector: ChangeDetectorRef
  ) { }

  public editTrip(trip: Trip): void {
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['edit-trip']);
  }

  // Send visitors through login before opening the reservation form
  public reserveTrip(trip: Trip): void {
    if (!this.authenticationService.isLoggedIn()) {
      this.router.navigate(
        ['/login'],
        {
          queryParams: {
            returnUrl: `/reserve/${trip.code}`
          }
        }
      );

      return;
    }

    this.router.navigate([
      '/reserve',
      trip.code
    ]);
  }

  // Display an in-page confirmation before deletion
  public requestDelete(trip: Trip): void {
    this.pendingDeleteCode = trip.code;
    this.changeDetector.detectChanges();
  }

  // Cancel the pending deletion without changing data
  public cancelDelete(): void {
    this.pendingDeleteCode = null;
    this.changeDetector.detectChanges();
  }

  // Delete only after the administrator confirms the request
  public deleteTrip(trip: Trip): void {
    this.tripDataService.deleteTrip(trip.code).subscribe({
      next: () => {
        this.tripDeleted.emit(trip.code);
        this.pendingDeleteCode = null;
        this.changeDetector.detectChanges();
      },
      error: (error: any) => {
        console.error('Trip deletion failed:', error);
        this.pendingDeleteCode = null;
        this.changeDetector.detectChanges();
      }
    });
  }

  // Restrict trip editing controls to administrators
  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }
}