import { Routes } from '@angular/router';
import { Login } from './login/login';
import { AddTrip } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';
import { TripListing } from './trip-listing/trip-listing';
import { Register } from './register/register';
import { Reservations } from './reservations/reservations';
import { ReserveTrip } from './reserve-trip/reserve-trip';

import {
  adminGuard,
  authenticatedGuard
} from './utils/route-guards';

export const routes: Routes = [
  {
    path: 'add-trip',
    component: AddTrip,
    canActivate: [adminGuard]
  },
  {
    path: 'edit-trip',
    component: EditTrip,
    canActivate: [adminGuard]
  },
  { path: 'login', component: Login },
  {
    path: 'register',
    component: Register
  },
  {
    path: 'reserve/:tripCode',
    component: ReserveTrip,
    canActivate: [authenticatedGuard]
  },
  {
    path: 'reservations',
    component: Reservations,
    canActivate: [authenticatedGuard]
  },
  { path: '', component: TripListing, pathMatch: 'full' }
];