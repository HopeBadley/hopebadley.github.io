// CS 499 Software Design and Engineering Enhancement
// Provides the customer workflow for reserving a selected trip.

import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';




@Component({
  selector: 'app-reserve-trip',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './reserve-trip.html',
  styleUrl: './reserve-trip.css'
})
export class ReserveTrip implements OnInit {
  reservationForm!: FormGroup;
  trip?: Trip;
  submitted = false;
  message = '';
  errorMessage = '';

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripData,
    private changeDetector: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.reservationForm = this.formBuilder.group({
      travelers: [
        1,
        [
          Validators.required,
          Validators.min(1),
          Validators.max(12)
        ]
      ]
    });

    const tripCode =
      this.route.snapshot.paramMap.get('tripCode');

    if (!tripCode) {
      this.router.navigate(['/']);
      return;
    }

    this.tripDataService.getTrip(tripCode).subscribe({
      next: (trip: Trip) => {
        this.trip = trip;
        this.changeDetector.detectChanges();
      },
      error: () => {
        this.errorMessage =
          'The selected trip could not be loaded.';
      }
    });
  }

  // Validate and submit a reservation for the selected trip
  onSubmit(): void {
    this.submitted = true;
    this.message = '';
    this.errorMessage = '';

    if (
      this.reservationForm.invalid ||
      !this.trip
    ) {
      return;
    }

    const travelers =
      Number(this.reservationForm.value.travelers);

    this.tripDataService
      .createReservation(this.trip.code, travelers)
      .subscribe({
        next: () => {
          this.message =
            'Your reservation was created successfully.';
          this.reservationForm.disable();
        },
        error: (error: any) => {
          this.errorMessage =
            error.error?.message ||
            'The reservation could not be created.';
        }
      });
  }

  get f() {
    return this.reservationForm.controls;
  }
}