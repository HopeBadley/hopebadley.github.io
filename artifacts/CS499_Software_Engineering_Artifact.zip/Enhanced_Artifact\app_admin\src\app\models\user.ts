export class User {
    email: string;
    name: string;
    role: 'customer' | 'admin';

    constructor() {
        this.email = '';
        this.name = '';
        this.role = 'customer';
    }
}