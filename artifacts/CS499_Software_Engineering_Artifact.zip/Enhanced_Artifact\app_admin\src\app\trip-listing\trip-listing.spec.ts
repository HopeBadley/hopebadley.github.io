import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';

import { TripListing } from './trip-listing';

describe('TripListing', () => {
  let component: TripListing;
  let fixture: ComponentFixture<TripListing>;

  const tripDataMock = {
    getTrips: vi.fn().mockReturnValue(of([]))
  };

  const authenticationMock = {
    isAdmin: vi.fn().mockReturnValue(false)
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripListing],
      providers: [
        provideRouter([]),
        {
          provide: Authentication,
          useValue: authenticationMock
        }
      ]
    })
      .overrideComponent(TripListing, {
        set: {
          providers: [
            {
              provide: TripData,
              useValue: tripDataMock
            }
          ]
        }
      })
      .compileComponents();

    fixture = TestBed.createComponent(TripListing);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
