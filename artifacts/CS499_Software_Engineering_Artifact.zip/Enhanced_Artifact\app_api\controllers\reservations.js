// CS 499 Software Design and Engineering Enhancement
// Controls customer reservations and administrator status updates.

const mongoose = require('mongoose');
const Reservation = require('../models/reservation');
const Trip = require('../models/travlr');
const { sendApiError } = require('../utils/api-error');

// Add limited user and trip details to reservation results
const populateReservation = (query) => {
  return query
    .populate('user', 'name email role')
    .populate(
      'trip',
      'code name start resort perPerson'
    );
};

// GET: /api/reservations
const reservationsList = async (req, res) => {
  try {
    // Administrators see all reservations; customers see only their own
    const filter = req.auth.role === 'admin'
      ? {}
      : { user: req.auth._id };

    const reservations = await populateReservation(
      Reservation
        .find(filter)
        .sort({ createdAt: -1 })
    ).exec();

    return res.status(200).json(reservations);
  } catch (err) {
    return sendApiError(
      res,
      500,
      'Reservations could not be retrieved.',
      err
    );
  }
};

// POST: /api/reservations
const reservationsCreate = async (req, res) => {
  const travelers = Number(req.body.travelers);

  if (
    !req.body.tripCode ||
    !Number.isInteger(travelers) ||
    travelers < 1 ||
    travelers > 12
  ) {
    return sendApiError(
      res,
      400,
      'A valid trip code and traveler count from 1 to 12 are required.'
    );
  }

  try {
    const trip = await Trip
      .findOne({ code: req.body.tripCode })
      .exec();

    if (!trip) {
      return sendApiError(
        res,
        404,
        'Trip not found.'
      );
    }

    const reservation = new Reservation({
      user: req.auth._id,
      trip: trip._id,
      travelers
    });

    await reservation.save();

    await reservation.populate([
      {
        path: 'user',
        select: 'name email role'
      },
      {
        path: 'trip',
        select: 'code name start resort perPerson'
      }
    ]);

    return res.status(201).json(reservation);
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Reservation could not be created.',
      err
    );
  }
};

// PATCH: /api/reservations/:reservationId/status
const reservationsUpdateStatus = async (req, res) => {
  const allowedStatuses = [
    'pending',
    'confirmed',
    'cancelled'
  ];

  if (!allowedStatuses.includes(req.body.status)) {
    return sendApiError(
      res,
      400,
      'Status must be pending, confirmed, or cancelled.'
    );
  }

  if (!mongoose.isValidObjectId(req.params.reservationId)) {
    return sendApiError(
      res,
      400,
      'Invalid reservation identifier.'
    );
  }

  try {
    const reservation = await populateReservation(
      Reservation.findByIdAndUpdate(
        req.params.reservationId,
        { status: req.body.status },
        {
          new: true,
          runValidators: true
        }
      )
    ).exec();

    if (!reservation) {
      return sendApiError(
        res,
        404,
        'Reservation not found.'
      );
    }

    return res.status(200).json(reservation);
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Reservation status could not be updated.',
      err
    );
  }
};

// PATCH: /api/reservations/:reservationId/cancel
const reservationsCancel = async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.reservationId)) {
    return sendApiError(
      res,
      400,
      'Invalid reservation identifier.'
    );
  }

  try {
    const reservation = await Reservation
      .findById(req.params.reservationId)
      .exec();

    if (!reservation) {
      return sendApiError(
        res,
        404,
        'Reservation not found.'
      );
    }

    const ownsReservation =
      reservation.user.toString() === req.auth._id;

    if (
      req.auth.role !== 'admin' &&
      !ownsReservation
    ) {
      return sendApiError(
        res,
        403,
        'You do not have permission to cancel this reservation.'
      );
    }

    if (reservation.status === 'cancelled') {
      return sendApiError(
        res,
        409,
        'This reservation is already cancelled.'
      );
    }

    reservation.status = 'cancelled';
    await reservation.save();

    return res.status(200).json(reservation);
  } catch (err) {
    return sendApiError(
      res,
      400,
      'Reservation could not be cancelled.',
      err
    );
  }
};

module.exports = {
  reservationsList,
  reservationsCreate,
  reservationsUpdateStatus,
  reservationsCancel
};