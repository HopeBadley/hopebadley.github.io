import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';

import { TripCard } from './trip-card';

describe('TripCard', () => {
  let component: TripCard;
  let fixture: ComponentFixture<TripCard>;

  const testTrip = {
    code: 'TEST001',
    name: 'Test Trip',
    resort: 'Test Resort',
    length: '3 days',
    start: '2026-10-01',
    perPerson: '500',
    image: 'test.jpg',
    description: 'Test description'
  } as Trip;

  const authenticationMock = {
    isLoggedIn: vi.fn().mockReturnValue(false),
    isAdmin: vi.fn().mockReturnValue(false)
  };

  const tripDataMock = {
    deleteTrip: vi.fn()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripCard],
      providers: [
        provideRouter([]),
        {
          provide: Authentication,
          useValue: authenticationMock
        },
        {
          provide: TripData,
          useValue: tripDataMock
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TripCard);
    component = fixture.componentInstance;
    component.trip = testTrip;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
