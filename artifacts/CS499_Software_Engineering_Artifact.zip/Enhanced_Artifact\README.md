# CS 465 Full Stack Development Portfolio

## Architecture

### Frontend Development

This project used different approaches for the customer-facing and administrative sides of the Travlr Getaways application. The customer-facing website used Express, HTML, Handlebars templates, CSS, and JavaScript. Express handled the server-side routes, while Handlebars generated pages using trip information retrieved through the application. This approach worked well for displaying travel information to customers.

The administrative side was developed as an Angular single-page application (SPA). Unlike the Express website, the Angular application did not need to load an entirely new webpage after each action. Angular used components and client-side routing to update the displayed content. Components were created for the navigation bar, login page, trip listing, trip cards, and the add and edit trip forms. This made the administrative side more interactive and easier to organize.

JavaScript was used in the Express and Node.js portions of the application, while Angular used TypeScript. TypeScript builds on JavaScript by adding features such as data types, interfaces, and compile-time error checking. Although the Express website and Angular SPA were developed differently, both communicated with the REST API to access trip data.

### MongoDB Database

The backend used MongoDB because it is a NoSQL database that stores information in document-style records. This structure worked well for the project because each trip could be stored as one document containing its code, name, length, start date, resort, price, image, and description.

MongoDB documents closely resemble the JSON objects used by the API. This made it easier to transfer data between MongoDB, Express, and Angular. Mongoose was used to create schemas, validate information, and interact with the database through JavaScript methods. MongoDB also provides flexibility if the structure of the application’s data needs to change later.

## Functionality

### JavaScript and JSON

JavaScript is a programming language used to create application logic and interactive behavior. It supports functions, variables, objects, classes, and conditional statements. JSON, or JavaScript Object Notation, is a text-based format used to represent and exchange data. Although JSON looks similar to a JavaScript object, it does not contain executable functions or application logic.

JSON connected the frontend and backend portions of the Travlr Getaways application. The API retrieved trip documents from MongoDB and returned the information as JSON. The customer-facing website and Angular SPA could then request that information and display it to the user. JSON was also used to send information from the administrative application to the API when adding or updating a trip.

### Refactoring and Reusable Components

One example of refactoring was moving the trip information out of static page content and into MongoDB. The application could then retrieve the current trip records through the API instead of repeating the same information in multiple files. This created one central source of data and made the application easier to update.

The Angular administrative interface was also divided into reusable components and services. The trip-card component controlled how an individual trip was displayed, while the trip-listing component handled the collection of available trips. The TripData service centralized API operations such as retrieving all trips, retrieving one trip, adding a trip, and updating a trip. An authentication service was also created to manage login requests and the stored authentication token.

Reusable UI components reduce duplicated code and create a consistent interface. For example, changing the trip-card component updates the appearance of every displayed trip card. Services also separate data-access logic from the visual components, making the application easier to understand, maintain, and troubleshoot.

## Testing

A method describes the type of action being requested from an API. In this project, GET requests retrieved trip information, POST requests submitted new information or login credentials, and PUT requests updated existing trip records. An endpoint is the specific API location that receives a request. Examples included `/api/trips` for the trip collection, `/api/trips/:tripCode` for a specific trip, and `/api/register` and `/api/login` for authentication.

I used Postman to test the API while the Express server and MongoDB database were running. I verified that `GET /api/trips` returned the available trip records. I also tested a PUT request that updated a trip using its trip code. Registration and login requests were tested, and successful authentication returned a JSON Web Token (JWT).

Security added another layer to API testing. Protected requests required an Authorization header containing a valid bearer token. A request without a token or with an altered token returned an unauthorized response. This showed that testing a secured endpoint requires more than checking the method, URL, and request body. It also requires confirming that valid authentication permits access and that invalid or missing authentication is rejected.

The complete application also required testing the connections among Angular, Express, the API, Mongoose, and MongoDB. Testing each layer separately helped identify whether a problem came from the frontend, server, route, controller, or database.

## Reflection

This course helped me understand how the separate layers of a full stack application work together. Before completing this project, I understood programming logic, but this course gave me direct experience connecting a user interface, server, REST API, authentication system, and database in one application. I developed both a customer-facing website and an administrative SPA instead of working with only one part of a system.

I gained experience with HTML, CSS, JavaScript, TypeScript, Express, Angular, Node.js, MongoDB, Mongoose, REST APIs, Postman, Git, and GitHub. I also learned how to create API routes and controllers, retrieve and update database records, build reusable Angular components and services, and troubleshoot communication problems between application layers. Adding password security and JWT authentication improved my understanding of how an application verifies users and protects restricted operations.

These skills support my professional goal of becoming a software developer and make me a more marketable candidate because I can demonstrate experience across the full stack. The project also strengthened my debugging and problem-solving abilities. I learned to interpret error messages, test individual layers, locate the source of a problem, and verify that a correction worked. I now have a completed portfolio project that demonstrates my ability to design, build, secure, test, and document a full stack web application.
