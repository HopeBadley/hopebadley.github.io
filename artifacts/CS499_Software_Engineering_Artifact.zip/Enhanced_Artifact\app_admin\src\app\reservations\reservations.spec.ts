import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';
import { Reservations } from './reservations';

describe('Reservations', () => {
  let component: Reservations;
  let fixture: ComponentFixture<Reservations>;

  const tripDataMock = {
    getReservations: vi.fn().mockReturnValue(of([])),
    updateReservationStatus: vi.fn(),
    cancelReservation: vi.fn()
  };

  const authenticationMock = {
    isAdmin: vi.fn().mockReturnValue(false)
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Reservations],
      providers: [
        { provide: TripData, useValue: tripDataMock },
        { provide: Authentication, useValue: authenticationMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(Reservations);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
