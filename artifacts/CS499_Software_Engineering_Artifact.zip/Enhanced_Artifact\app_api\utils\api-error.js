// CS 499 Software Design and Engineering Enhancement
// Returns consistent errors without exposing internal database details.

// Log technical details on the server and send a safe message to the user
const sendApiError = (res, status, message, error = null) => {
  if (error) {
    console.error(error);
  }

  return res.status(status).json({
    message
  });
};

module.exports = {
  sendApiError
};