import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Inject, Injectable } from '@angular/core';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';
import { environment } from '../../environments/environment';
import { Reservation } from '../models/reservation';

@Injectable({
  providedIn: 'root'
})
export class TripData {
  private baseUrl = environment.apiBaseUrl;
  private url = `${this.baseUrl}/trips`;

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) { }

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData);
  }

  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(this.url + '/' + tripCode);
  }

  updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(
      this.url + '/' + formData.code,
      formData
    );
  }

  // Delete one trip by its unique trip code
  deleteTrip(tripCode: string): Observable<{
    message: string;
    trip: Trip;
  }> {
    return this.http.delete<{
      message: string;
      trip: Trip;
    }>(
      `${this.url}/${tripCode}`
    );
  }

  // Retrieve reservations permitted for the logged-in user
  getReservations(): Observable<Reservation[]> {
    return this.http.get<Reservation[]>(
      `${this.baseUrl}/reservations`
    );
  }

  // Create a reservation for the logged-in customer
  createReservation(
    tripCode: string,
    travelers: number
  ): Observable<Reservation> {
    return this.http.post<Reservation>(
      `${this.baseUrl}/reservations`,
      {
        tripCode,
        travelers
      }
    );
  }

  // Allow an administrator to update reservation status
  updateReservationStatus(
    reservationId: string,
    status: 'pending' | 'confirmed' | 'cancelled'
  ): Observable<Reservation> {
    return this.http.patch<Reservation>(
      `${this.baseUrl}/reservations/${reservationId}/status`,
      {
        status
      }
    );
  }

  // Allow a customer to cancel an owned reservation
  cancelReservation(
    reservationId: string
  ): Observable<Reservation> {
    return this.http.patch<Reservation>(
      `${this.baseUrl}/reservations/${reservationId}/cancel`,
      {}
    );
  }

  login(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, passwd);
  }

  register(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, passwd);
  }

  private handleAuthAPICall(
    endpoint: string,
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(
      this.baseUrl + '/' + endpoint,
      formData
    );
  }
}