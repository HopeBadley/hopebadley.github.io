import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { TripData } from './trip-data';
import {
  Observable,
  tap
} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Authentication {

  // Variable to handle authentication responses
  authResp: AuthResponse = new AuthResponse();

  // Set up storage and service access
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripData
  ) { }

  // Get the JWT from local storage
  public getToken(): string {
    const out = this.storage.getItem('travlr-token');

    if (!out) {
      return '';
    }

    return out;
  }

  // Save the JWT to local storage
  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  // Remove the JWT when logging out
  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  // Determine whether the stored token exists and has not expired
  public isLoggedIn(): boolean {
    const token: string = this.getToken();

    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    }

    return false;
  }

  // Retrieve the currently logged-in user
  public getCurrentUser(): User {
    const token: string = this.getToken();
    const { email, name, role } = JSON.parse(
      atob(token.split('.')[1])
    );

    return { email, name, role } as User;
  }

  // Determine whether the current user has administrator permission
  public isAdmin(): boolean {
    if (!this.isLoggedIn()) {
      return false;
    }

    return this.getCurrentUser().role === 'admin';
  }

  // Save the token before notifying the component that login finished
  public login(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.tripDataService
      .login(user, passwd)
      .pipe(
        tap((response: AuthResponse) => {
          this.authResp = response;
          this.saveToken(response.token);
        })
      );
  }

  // Save the token before notifying the component that registration finished
  public register(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.tripDataService
      .register(user, passwd)
      .pipe(
        tap((response: AuthResponse) => {
          this.authResp = response;
          this.saveToken(response.token);
        })
      );
  }
}