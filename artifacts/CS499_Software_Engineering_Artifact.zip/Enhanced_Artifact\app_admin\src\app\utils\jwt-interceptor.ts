import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { Authentication } from '../services/authentication';

export const jwtInterceptor: HttpInterceptorFn = (request, next) => {
  const authenticationService = inject(Authentication);

  const isAuthAPI =
    request.url.includes('/api/login') ||
    request.url.includes('/api/register');

  if (authenticationService.isLoggedIn() && !isAuthAPI) {
    const token = authenticationService.getToken();

    const authenticatedRequest = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });

    return next(authenticatedRequest);
  }

  return next(request);
};