import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  ActivatedRoute,
  convertToParamMap,
  provideRouter
} from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { ReserveTrip } from './reserve-trip';

describe('ReserveTrip', () => {
  let component: ReserveTrip;
  let fixture: ComponentFixture<ReserveTrip>;

  const testTrip = {
    code: 'TEST001',
    name: 'Test Trip',
    resort: 'Test Resort',
    length: '3 days',
    start: '2026-10-01',
    perPerson: '500',
    image: 'test.jpg',
    description: 'Test description'
  } as Trip;

  const tripDataMock = {
    getTrip: vi.fn().mockReturnValue(of(testTrip)),
    createReservation: vi.fn()
  };

  const activatedRouteMock = {
    snapshot: {
      paramMap: convertToParamMap({
        tripCode: 'TEST001'
      })
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReserveTrip],
      providers: [
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: activatedRouteMock
        },
        {
          provide: TripData,
          useValue: tripDataMock
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ReserveTrip);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
