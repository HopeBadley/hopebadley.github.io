import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

import { EditTrip } from './edit-trip';

describe('EditTrip', () => {
  let component: EditTrip;
  let fixture: ComponentFixture<EditTrip>;

  const testTrip = {
    code: 'TEST001',
    name: 'Test Trip',
    resort: 'Test Resort',
    length: '3 days',
    start: '2026-10-01',
    perPerson: '500',
    image: 'test.jpg',
    description: 'Test description'
  } as Trip;

  const tripDataMock = {
    getTrip: vi.fn().mockReturnValue(of(testTrip)),
    updateTrip: vi.fn()
  };

  const storageMock = {
    getItem: vi.fn().mockReturnValue('TEST001'),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn()
  };

  beforeEach(async () => {
    vi.stubGlobal('localStorage', storageMock);
    await TestBed.configureTestingModule({
      imports: [EditTrip],
      providers: [
        provideRouter([]),
        {
          provide: TripData,
          useValue: tripDataMock
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(EditTrip);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
