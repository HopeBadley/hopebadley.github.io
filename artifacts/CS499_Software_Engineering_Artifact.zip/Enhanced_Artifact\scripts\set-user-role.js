// CS 499 Software Design and Engineering Enhancement
// Changes an existing user's role through a local administrator utility.

require('dotenv').config();

const mongoose = require('mongoose');
const User = require('../app_api/models/user');

const email = process.argv[2];
const role = process.argv[3];

if (
  !email ||
  !['customer', 'admin'].includes(role)
) {
  console.error(
    'Usage: node scripts/set-user-role.js <email> <customer|admin>'
  );
  process.exit(1);
}

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

mongoose
  .connect(dbURI)
  .then(async () => {
    const user = await User.findOneAndUpdate(
      { email },
      { role },
      {
        new: true,
        runValidators: true
      }
    ).exec();

    if (!user) {
      throw new Error('User not found.');
    }

    console.log(
      `${user.email} now has the ${user.role} role.`
    );
  })
  .catch((err) => {
    console.error(err.message);
    process.exitCode = 1;
  })
  .finally(() => {
    mongoose.disconnect();
  });