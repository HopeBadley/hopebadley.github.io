// CS 499 Software Design and Engineering Enhancement
// Prevents unauthorized navigation in the Angular application.

import { inject } from '@angular/core';
import {
    CanActivateFn,
    Router
} from '@angular/router';

import { Authentication } from '../services/authentication';

// Require a valid login before opening customer account pages
export const authenticatedGuard: CanActivateFn = () => {
    const authentication = inject(Authentication);
    const router = inject(Router);

    if (authentication.isLoggedIn()) {
        return true;
    }

    return router.createUrlTree(['/login']);
};

// Require the administrator role before opening management pages
export const adminGuard: CanActivateFn = () => {
    const authentication = inject(Authentication);
    const router = inject(Router);

    if (!authentication.isLoggedIn()) {
        return router.createUrlTree(['/login']);
    }

    if (!authentication.isAdmin()) {
        return router.createUrlTree(['/']);
    }

    return true;
};