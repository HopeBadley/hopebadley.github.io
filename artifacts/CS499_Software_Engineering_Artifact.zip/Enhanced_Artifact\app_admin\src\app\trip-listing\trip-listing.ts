import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCard],
  providers: [TripData],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  message: string = '';
  successMessage: string = '';

  constructor(
    private tripDataService: TripData,
    private changeDetector: ChangeDetectorRef,
    private router: Router,
    private authenticationService: Authentication
  ) {
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  // Remove the deleted trip from the current interface
  public removeTrip(tripCode: string): void {
    this.trips = this.trips.filter(
      (trip) => trip.code !== tripCode
    );

    this.message =
      'There are ' + this.trips.length + ' trips available.';

    this.successMessage =
      'Trip deleted successfully.';

    this.changeDetector.detectChanges();
  }

  // Show management controls only to administrators
  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }

  private getStuff(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;

        if (value.length > 0) {
          this.message =
            'There are ' + value.length + ' trips available.';
        } else {
          this.message =
            'There were no trips retrieved from the database.';
        }

        console.log(this.message);
        this.changeDetector.detectChanges();
      },
      error: (error: any) => {
        console.log('Error: ', error);
      }
    });
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
  }
}