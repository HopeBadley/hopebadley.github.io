//CS 499 Software Design and Engineering Enhancement
// Centralizes authentication and role-based authorization.

const jwt = require('jsonwebtoken');

// Verify that the request contains a valid JSON Web Token
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      message: 'Authentication required.'
    });
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({
      message: 'Invalid authorization header.'
    });
  }

  try {
    req.auth = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch (error) {
    return res.status(401).json({
      message: 'Invalid or expired token.'
    });
  }
};

// Allow access only when the authenticated user has an approved role
const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.auth || !allowedRoles.includes(req.auth.role)) {
      return res.status(403).json({
        message: 'You do not have permission to perform this action.'
      });
    }

    return next();
  };
};

module.exports = {
  authenticateJWT,
  requireRole
};