// CS 499 Software Design and Engineering Enhancement
// Displays customer history and administrator reservation controls.

import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { Reservation } from '../models/reservation';
import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-reservations',
  imports: [CommonModule],
  templateUrl: './reservations.html',
  styleUrl: './reservations.css'
})
export class Reservations implements OnInit {
  reservations: Reservation[] = [];
  message = '';
  errorMessage = '';

  constructor(
    private tripDataService: TripData,
    private authenticationService: Authentication,
    private changeDetector: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.loadReservations();
  }

  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }

  // Retrieve only the reservations allowed by the server
  private loadReservations(): void {
    this.tripDataService.getReservations().subscribe({
      next: (reservations: Reservation[]) => {
        this.reservations = reservations;
        this.changeDetector.detectChanges();

      },
      error: (error: any) => {
        this.errorMessage =
          error.error?.message ||
          'Reservations could not be loaded.';
        this.changeDetector.detectChanges();
      }
    });
  }

  // Administrators may confirm pending reservations
  public confirmReservation(
    reservation: Reservation
  ): void {
    this.tripDataService
      .updateReservationStatus(
        reservation._id,
        'confirmed'
      )
      .subscribe({
        next: (updated: Reservation) => {
          this.replaceReservation(updated);
          this.message = 'Reservation confirmed.';
          this.changeDetector.detectChanges();
        },
        error: (error: any) => {
          this.errorMessage =
            error.error?.message ||
            'Reservation could not be confirmed.';
        }
      });
  }

  // Customers cancel owned records; administrators update status
  public cancelReservation(
    reservation: Reservation
  ): void {
    const request = this.isAdmin()
      ? this.tripDataService.updateReservationStatus(
        reservation._id,
        'cancelled'
      )
      : this.tripDataService.cancelReservation(
        reservation._id
      );

    request.subscribe({
      next: (updated: Reservation) => {
        this.replaceReservation(updated);
        this.message = 'Reservation cancelled.';
        this.changeDetector.detectChanges();
      },
      error: (error: any) => {
        this.errorMessage =
          error.error?.message ||
          'Reservation could not be cancelled.';
        this.changeDetector.detectChanges();
      }
    });
  }

  // Replace one changed record without reloading the page
  private replaceReservation(
    updated: Reservation
  ): void {
    this.reservations = this.reservations.map(
      (reservation) =>
        reservation._id === updated._id
          ? updated
          : reservation
    );
  }
}