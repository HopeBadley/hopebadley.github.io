// CS 499 Software Design and Engineering Enhancement
// Creates customer accounts and continues the reservation workflow.

import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

import { User } from '../models/user';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-register',
  imports: [
    CommonModule,
    FormsModule,
    RouterLink
  ],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register {
  formError = '';

  credentials = {
    name: '',
    email: '',
    password: ''
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: Authentication
  ) {}

  // Validate the form before creating a customer account
  onRegisterSubmit(): void {
    this.formError = '';

    if (
      !this.credentials.name ||
      !this.credentials.email ||
      !this.credentials.password
    ) {
      this.formError = 'All fields are required.';
      return;
    }

    const user = {
      name: this.credentials.name,
      email: this.credentials.email,
      role: 'customer'
    } as User;

    this.authenticationService
      .register(user, this.credentials.password)
      .subscribe({
        next: () => {
          const returnUrl =
            this.route.snapshot.queryParamMap.get(
              'returnUrl'
            ) || '/';

          this.router.navigateByUrl(returnUrl);
        },
        error: (error: any) => {
          this.formError =
            error.error?.message ||
            'Registration was unsuccessful.';
        }
      });
  }
}